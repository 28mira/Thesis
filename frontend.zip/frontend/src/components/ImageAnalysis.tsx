import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import React from "react";
import FileUploadIcon from "@mui/icons-material/FileUpload";
import ImageUploading from "react-images-uploading";
import AddPohotoAlternate from "@mui/icons-material/AddPhotoAlternate";
import { HideImage } from "@mui/icons-material";
import Refresh from "@mui/icons-material/Refresh";
import { set, useForm } from "react-hook-form";
import { useState } from "react";
import { useEffect } from "react";
import { Card, Typography } from "@mui/material";

async function handleOnChange(image: any) {
  let tumortype = 0;
  try {
    const formData = new FormData();
    formData.append("image", image.file);
    const response = await fetch("http://localhost:5000/api/upload", {
      method: "POST",
      body: formData,
    });
    const resp = await response.json();
    console.log("Success:", resp);
    tumortype = Number(resp.prediction[0]);
  } catch (error) {
    console.error("Error", error);
  }
  return tumortype;
}

const ImageAnalysis = () => {
  const [image, setImage] = React.useState([]);
  const [showDetails, setShowDetails] = useState(false);
  const [tumorType, setTumorType] = useState(0);
  const [resultData, setResultData] = useState({
    label: null,
    content: null,
    accuracy: null,
  });

  useEffect(() => {
    fetch(`http://localhost:5000/imageAnalyze/result?type=${tumorType}`)
      .then((response) => response.json())
      .then((data) => {
        setResultData({
          label: data.label,
          content: data.content,
          accuracy: data.accuracy,
        });
      })
      .catch((error) => console.error("Error fetching message:", error));
  }, [tumorType]);

  const onChange = (imageList: any, addUpdateIndex: any) => {
    console.log(imageList, addUpdateIndex);
    setImage(imageList);
  };

  return (
    <Box
      flexDirection="row"
      alignItems="flex-start"
      justifyContent="center"
      textAlign="left"
      width="75%"
      height="min-content"
      bgcolor="#ffffffff"
      padding={2}
      marginTop={3}
      display={{ xs: "block", md: "flex" }}
    >
      <Card
        variant="outlined"
        sx={{
          flexDirection: "column",
          padding: 3,
          marginBottom: 3,
          borderRadius: 10,
          color: "#002360ff",
          borderColor: "#073c8bff",
        }}
      >
        <Typography variant="h3">Képelemzés</Typography>
        <Typography variant="body1" sx={{ marginTop: 2, marginBottom: 2 }}>
          Mestereséges intelligencia segítségével elemzésre kerül az ide
          feltöltött kép, ami 4 / 5 féle diagnózist adhat vissza. A modell 3
          féle elváltozást ismer fel ezek a meningeóma, a glióma és az agyalapi
          mirigy daganat, ezeken kívül lehet más fajta elváltozás is és teljesen
          egészséges kép az agyról.
        </Typography>

        <div className="imageUpload" style={{ textAlign: "center" }}>
          <ImageUploading
            value={image}
            onChange={onChange}
            dataURLKey="data_url"
            acceptType={["jpg"]}
          >
            {({
              imageList,
              onImageUpload,
              onImageRemove,
              isDragging,
              dragProps,
            }) => (
              <div>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={onImageUpload}
                >
                  <AddPohotoAlternate />
                </Button>
                {imageList.map((image, index) => (
                  <div key={index} className="imageItem">
                    <Box sx={{ margin: 1 }}>
                      <img src={image["data_url"]} alt="image" width="100" />
                    </Box>
                    <div>
                      <Button
                        sx={{ marginRight: 1 }}
                        variant="contained"
                        color="error"
                        onClick={() => onImageRemove(index)}
                      >
                        <HideImage />
                      </Button>
                      &nbsp;
                      <Button
                        sx={{ marginRight: 1 }}
                        variant="contained"
                        color="success"
                        onClick={() => {
                          handleOnChange(image).then((type) => {
                            setTumorType(type);
                          });
                          setShowDetails(true);
                        }}
                      >
                        <FileUploadIcon />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ImageUploading>
        </div>
      </Card>
      {showDetails && (
        <Card
          variant="outlined"
          sx={{
            flexDirection: "column",
            padding: 3,
            marginBottom: 3,
            marginLeft: { md: 4 },
            borderRadius: 10,
            color: "#002360ff",
            borderColor: "#073c8bff",
          }}
        >
          <Typography
            variant="h3"
            sx={{
              marginBottom: 2,
            }}
          >
            Eredmény
          </Typography>
          <Typography variant="h5">{resultData.label}:</Typography>
          <Typography>{resultData.content}</Typography>
        </Card>
      )}
    </Box>
  );
};

export default ImageAnalysis;
